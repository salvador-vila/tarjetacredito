package utilidades;



public class Utilidades {

    public static final String TABLA_USUARIO="usuario";
    public static final String nombre="nombre";
    public static final String apellido="apellido";
    public static final String AlO="año";
    public static final String NUMERO_TARJETA="numero tarjeta";
    public static final String MES="mes";
    public static final String CODIGO="codigo";
    public static final String DIRECCION="direccion";
    public static final String CALLE_NUMERO="calle numero";
    public static final String CIUDAD="ciudad";
    public static final String ESTADO="estado";
    public static final String CODIGO_POSTAL="codigo postal";

    public static final String CREAR_TABLA_USUARIO="CREATE TABLE "+TABLA_USUARIO+" ("+nombre+" TEXT, "+apellido+" TEXT, "+AlO+" TEXT, "+NUMERO_TARJETA+" TEXT, "+MES+" TEXT, "+CODIGO+" TEXT, "+DIRECCION+" TEXT, "+CALLE_NUMERO+" TEXT, "+CIUDAD+" TEXT, "+ESTADO+" TEXT, "+CODIGO_POSTAL+" TEXT)";

}
